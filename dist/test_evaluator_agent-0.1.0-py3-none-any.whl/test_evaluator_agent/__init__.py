"""Test Evaluator Agent - AI-powered data extraction evaluator using LangGraph"""

__version__ = "0.1.0"
__author__ = "Agentic Data Mining"
__email__ = "noreply@example.com"